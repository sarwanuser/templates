<?php

namespace App\Auth;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
   
    protected $table = 'projects';

    protected $primaryKey = 'id';
}

