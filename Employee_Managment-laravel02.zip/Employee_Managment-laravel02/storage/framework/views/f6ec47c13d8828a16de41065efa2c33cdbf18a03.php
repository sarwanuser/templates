<?php if(@$errors): ?>
<?php if(count($errors) > 0): ?>
    <div class="card-alert card card-alert card gradient-45deg-red-pink ensober_alert"> 
        <button type="button" class="close" data-dismiss="alert">×</button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="color:#fff;"><i class="material-icons">clear</i> <?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php endif; ?>

<?php if(Session::has('flash_error')): ?>
	<div class="card-alert card card-alert card gradient-45deg-red-pink ensober_alert"> 
		<div class="card-content white-text">
			<p><i class="material-icons">check</i> <?php echo e(Session::get('flash_error')); ?>.</p>
		</div>
		<button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
		</button>
	</div>
<?php endif; ?>


<?php if(Session::has('flash_success')): ?> 
	<div class="card-alert card card-alert card gradient-45deg-green-teal ensober_alert"> 
		<div class="card-content white-text">
			<p><i class="material-icons">check</i> <?php echo Session::get('flash_success'); ?>.</p>
		</div>
		<button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">×</span>
		</button>
	</div>
<?php endif; ?><?php /**PATH E:\Lumen\Employee_Management\resources\views////common/notify.blade.php ENDPATH**/ ?>