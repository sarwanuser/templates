<!doctype html>
<html lang="zxx" class="theme-light">
	
<!-- Mirrored from templates.envytheme.com/startp/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 20 Jan 2023 05:40:28 GMT -->
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- All CSS Link -->
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/animate.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/meanmenu.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/boxicons.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/magnific-popup.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/owl.carousel.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/flaticon.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/odometer.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/slick.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/style.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/responsive.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(URL::asset('content/assets/css/dark-color/dark-style.css')); ?>">
		
		<title>StartP - IT Startup & Digital Business Services HTML Template</title>

		<link rel="icon" type="image/png" href="assets/img/favicon.png">

		<!-- All JS Link -->
		<script src="<?php echo e(URL::asset('content/assets/js/jquery.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/bootstrap.bundle.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/meanmenu.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/wow.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/magnific-popup.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/appear.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/odometer.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('content/assets/js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('content/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('content/assets/js/isotope.pkgd.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('content/assets/js/owl.carousel.min.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/feather.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('content/assets/js/form-validator.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('content/assets/js/contact-form-script.js')); ?>"></script>
		<script src="<?php echo e(URL::asset('content/assets/js/main.js')); ?>"></script>
	</head><?php /**PATH E:\Lumen\Employee_Management\resources\views/MngContent/Base.blade.php ENDPATH**/ ?>