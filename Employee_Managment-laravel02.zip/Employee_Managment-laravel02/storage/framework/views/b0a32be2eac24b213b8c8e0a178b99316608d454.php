

<?php $__env->startSection('title', 'Employee Personal Information'); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
            <h3 class="page-title"> Employees Attendance Details</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                <!-- <li class="breadcrumb-item"><a href="#">Tables</a></li> -->
                <!-- <li class="breadcrumb-item active" aria-current="page">Basic tables</li> -->
                </ol>
            </nav>
            </div>
            <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                <div class="card-body">
                    <!-- <h4 class="card-title">Hoverable Table</h4>
                    <p class="card-description"> Add class <code>.table-hover</code> -->
                    </p>
                    <div class="table-responsive">
                    <table class="table table-hover" id="datatablesSimple">
                        <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Employee Name</th>
                            <th>Employee Code</th>
                            <th>Check-In</th>
                            <th>Check-Out</th>
                            <th>Total Working Time</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $x=1; ?>
                        <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($x++); ?></td>
                            <td><?php echo e($employee->emp_name); ?> </td>
                            <td><?php echo e($employee->emp_code); ?></td>
                            <td><?php echo e(date("d-m-Y h:i:s A", strtotime($employee->check_in))); ?></td>
                            <td><?php if(!empty($employee->check_out)): ?> <?php echo e(date("d-m-Y h:i:s A", strtotime($employee->check_out))); ?>  <?php else: ?> - <?php endif; ?></td>
                            <td><?php if(!empty($employee->total_work)): ?> <?php echo e($employee->total_work); ?> Hours <?php else: ?> - <?php endif; ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::asset('js/datatables-simple-demo.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Lumen\Employee_Management\resources\views/user/AllAttendance.blade.php ENDPATH**/ ?>