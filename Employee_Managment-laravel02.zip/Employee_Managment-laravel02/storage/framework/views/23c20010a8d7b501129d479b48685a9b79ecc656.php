

<?php $__env->startSection('title', 'Home Top Contents'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        i{
            font-size: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        
<div class="main-panel">
        <div class="content-wrapper">
            <div class="row">                    
                <div class="col-12 grid-margin">
                    <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Top Contents</h4>
                        <form class="form-sample" id="myForm" action="javascript:void(0)" accept-charset="utf-8" enctype="multipart/form-data">
                        <!-- <p class="card-description"> Personal info </p> -->
                        <div class="row">
                            <div class="col-md-12">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Heading</label>
                                <div class="col-sm-9">
                                    <!-- <input type="text" class="form-control" required name="first_name" /> -->
                                    <textarea class="form-control" name="" id="" cols="80" rows="5"></textarea>
                                </div>
                            </div>
                            </div>
                            <div class="col-md-12">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Paragraph</label>
                                <div class="col-sm-9">
                                <textarea class="form-control" name="" id="" cols="80" rows="5"></textarea>
                                </div>
                            </div>
                            </div>
                        </div>

                        <div class="row">
                            <button type="submit" id="submit_btn" class="btn btn-primary mr-2">Add</button>
                            <div id="alertMSG" style="font-size: 12px; padding: 2px; display: none">&nbsp;</div>
                        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Lumen\Employee_Management\resources\views/MngContent/Home/Top/create.blade.php ENDPATH**/ ?>