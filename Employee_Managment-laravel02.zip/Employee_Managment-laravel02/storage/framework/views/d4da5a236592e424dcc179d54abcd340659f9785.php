

<?php $__env->startSection('title', 'All Projects '); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        /* body{
            color: red !important;
        } */
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">All Projects </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <!-- <li class="breadcrumb-item"><a href="#">Tables</a></li> -->
                  <!-- <li class="breadcrumb-item active" aria-current="page">Basic tables</li> -->
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <!-- <h4 class="card-title">Hoverable Table</h4>
                    <p class="card-description"> Add class <code>.table-hover</code> -->
                    </p>
                    <div class="table-responsive">
                      <table class="table table-hover" id="datatablesSimple">
                        <thead>
                          <tr>
                            <th>Sr No.</th>
                            <th>Project Name</th>
                            <th>Project URL</th>
                            <th>Project Dev URL</th>
                            <th>Client Name</th>
                            <th>Working Employees</th>
                            <th>Project Budget</th>
                            <th>Created Date</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Timeline</th>
                            <th>Project Status</th>
                            <th>Status Change Date</th>
                            <th>Payment Status</th>
                            <th>Target Status</th>
                            <th>Created By</th>
                            <th>Updated By</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $x=1; ?>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($x++); ?></td>
                            <td><?php echo e($project->project_name); ?></td>
                            <td><?php echo e($project->project_url); ?></td>
                            <td><?php echo e($project->project_dev_url); ?></td>
                            <td><?php echo e($project->client_name); ?></td>
                            <td><?php echo e($project->working_emp); ?></td>
                            <td><?php echo e($project->budget); ?></td>
                            <td><?php echo e(date("d-m-Y", strtotime($project->created_date))); ?></td>
                            <td><?php if(!empty($project->start_date)): ?><?php echo e(date("d-m-Y", strtotime($project->start_date))); ?> <?php endif; ?></td>
                            <td><?php if(!empty($project->end_date)): ?><?php echo e(date("d-m-Y", strtotime($project->end_date))); ?> <?php endif; ?></td>
                            <td><?php echo e($project->timeline); ?> days</td>
                            <td>
                              <?php if($project->status=='ST'): ?>
                                Started
                              <?php elseif($project->status=='PL'): ?>
                                Planning
                              <?php elseif($project->status=='DV'): ?>
                                Developmemt
                              <?php elseif($project->status=='SG'): ?>
                                Staging
                              <?php elseif($project->status=='TS'): ?>
                                Testing
                              <?php elseif($project->status=='LV'): ?>
                                Live
                              <?php elseif($project->status=='DN'): ?>
                                Done
                              <?php elseif($project->status=='RW'): ?>
                                Re-Work
                              <?php elseif($project->status=='RT'): ?>
                                Re-Testing
                              <?php elseif($project->status=='PR'): ?>
                                Process
                              <?php endif; ?>

                            </td>
                            <td><?php if(!empty($project->status_change_date)): ?><?php echo e(date("d-m-Y", strtotime($project->status_change_date))); ?> <?php endif; ?></td>
                            <td>
                              <?php if($project->payment_status=='PN'): ?>
                                Pending
                              <?php elseif($project->payment_status=='PR'): ?>
                                Partial
                              <?php elseif($project->payment_status=='DU'): ?>
                                Due
                              <?php elseif($project->payment_status=='OD'): ?>
                                Over-Due
                              <?php elseif($project->payment_status=='DN'): ?>
                                Done  
                              <?php endif; ?>
                            </td>
                            <td>
                              <?php if($project->target_status=='FN'): ?>
                                Fine
                              <?php elseif($project->target_status=='WR'): ?>
                                Worning 
                              <?php elseif($project->target_status=='OD'): ?>
                                Over-Due  
                              <?php endif; ?>
                            </td>
                            <td><?php echo e($project->created_by); ?></td>
                            <td><?php echo e($project->updated_by); ?></td>
                            <th>
                                <a href="/admin/edit-project-<?php echo e($project->id); ?>"><i class="mdi mdi-table-edit" style="color: green;"></i></a>
                                <a href="/admin/delete-project-<?php echo e($project->id); ?>"><i class="mdi mdi-delete-forever" style="color: red;"></i></a>
                            </th>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(URL::asset('js/datatables-simple-demo.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Lumen\Employee_Management\resources\views/Admin/Projects/index.blade.php ENDPATH**/ ?>