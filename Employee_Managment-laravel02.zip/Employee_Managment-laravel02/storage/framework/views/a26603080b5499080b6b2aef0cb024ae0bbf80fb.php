

<?php $__env->startSection('title', 'Home Top Contents'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        i{
            font-size: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <?php echo $__env->make('MngContent.Base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Top Contents </h3>
              <nav aria-label="breadcrumb">
                <a href="/Manage-Home/top-create"><i class="mdi mdi mdi-plus-box" style="color: blue;"></i></a>
                <a href="/Manage-Home/top-edit"><i class="mdi mdi-table-edit" style="color: green;"></i></a>
                <a href="/Manage-Home/top-delete"><i class="mdi mdi-delete-forever" style="color: red;"></i></a>
              </nav>
            </div>

            <!-- Start Main Banner -->
		<div class="main-banner">
			<div class="d-table">
				<div class="d-table-cell">
					<div class="container">
						<div class="row h-100 justify-content-center align-items-center">
							<div class="col-lg-5">
								<div class="hero-content">
									<h1>Secure IT Solutions for a more secure environment</h1>
									<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.</p>
									
									<a href="contact.html" class="btn btn-primary">Get Started</a>
								</div>
							</div>

							<div class="col-lg-6 offset-lg-1">
								<div class="banner-image">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/man.png')); ?>" class="wow fadeInDown" data-wow-delay="0.6s" alt="man">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/code.png')); ?>" class="wow fadeInUp" data-wow-delay="0.6s" alt="code">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/carpet.png')); ?>" class="wow fadeInLeft" data-wow-delay="0.6s" alt="carpet">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/bin.png')); ?>" class="wow zoomIn" data-wow-delay="0.6s" alt="bin">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/book.png')); ?>" class="wow bounceIn" data-wow-delay="0.6s" alt="book">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/dekstop.png')); ?>" class="wow fadeInDown" data-wow-delay="0.6s" alt="dekstop">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/dot.png')); ?>" class="wow zoomIn" data-wow-delay="0.6s" alt="dot">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/flower-top-big.png')); ?>" class="wow fadeInUp" data-wow-delay="0.6s" alt="flower-top-big">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/flower-top.png')); ?>" class="wow rotateIn" data-wow-delay="0.6s" alt="flower-top">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/keyboard.png')); ?>" class="wow fadeInUp" data-wow-delay="0.6s" alt="keyboard">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/pen.png')); ?>" class="wow zoomIn" data-wow-delay="0.6s" alt="pen">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/table.png')); ?>" class="wow zoomIn" data-wow-delay="0.6s" alt="table">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/tea-cup.png')); ?>" class="wow fadeInLeft" data-wow-delay="0.6s" alt="tea-cup">
									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/headphone.png')); ?>" class="wow rollIn" data-wow-delay="0.6s" alt="headphone">

									<img src="<?php echo e(URL::asset('content/assets/img/banner-image/main-pic.png')); ?>" class="wow fadeInUp" data-wow-delay="0.6s" alt="main-pic">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>  

			<div class="shape1"><img src="<?php echo e(URL::asset('content/assets/img/shape1.png')); ?>" alt="shape"></div>
			<div class="shape2 rotateme"><img src="<?php echo e(URL::asset('content/assets/img/shape2.svg')); ?>" alt="shape"></div>
			<div class="shape3"><img src="<?php echo e(URL::asset('content/assets/img/shape3.svg')); ?>" alt="shape"></div>
			<div class="shape4"><img src="<?php echo e(URL::asset('content/assets/img/shape4.svg')); ?>" alt="shape"></div>
			<div class="shape5"><img src="<?php echo e(URL::asset('content/assets/img/shape5.png')); ?>" alt="shape"></div>
			<div class="shape6 rotateme"><img src="<?php echo e(URL::asset('content/assets/img/shape4.svg')); ?>" alt="shape"></div>
			<div class="shape7"><img src="<?php echo e(URL::asset('content/assets/img/shape4.svg')); ?>" alt="shape"></div>
			<div class="shape8 rotateme"><img src="<?php echo e(URL::asset('content/assets/img/shape2.svg')); ?>" alt="shape"></div>
		</div>
		<!-- End Main Banner -->

        
          <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Lumen\Employee_Management\resources\views/MngContent/Home/Top/index.blade.php ENDPATH**/ ?>